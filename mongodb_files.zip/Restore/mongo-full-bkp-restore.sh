#!/bin/bash

# Configuration
AZURE_STORAGE_URL="https://mongodbbackuptesting.blob.core.windows.net/mongodbbkp"
SAS_TOKEN="se=2099-12-31T23%3A59%3A59Z&sp=racwdl&spr=https&sv=2022-11-02&sr=c&sig=gTUG8z3%2BnWroBfgTsd0SOQeKxQTbn6Yx2rYVxEEaAUg%3D"
RESTORE_DIR="/home/ubuntu/mongorestore/full"
MONGODB_HOST="my-demo-replset/mongodb-master:27017"
MONGODB_USER="mongo-admin"
MONGODB_PASS="mongo-pass"
MONGODB_AUTH_DB="admin"

# Create restore directory
mkdir -p "$RESTORE_DIR"

# List all backup files and find the most recent one
LATEST_BACKUP=$(azcopy list "$AZURE_STORAGE_URL/full?$SAS_TOKEN" | grep '.tar.gz' | sort | tail -n 1)

# Extract only the file name (remove everything after ';')
LATEST_BACKUP_FILE=$(echo "$LATEST_BACKUP" | sed 's/;.*//')

# Form the URL to download the latest backup file
BACKUP_FILE="$AZURE_STORAGE_URL/full/$LATEST_BACKUP_FILE?$SAS_TOKEN"

# Download the latest backup file from Azure Blob Storage
azcopy copy "$BACKUP_FILE" "$RESTORE_DIR/backup.tar.gz"

# Check if download was successful
if [ $? -eq 0 ]; then
    echo "Download from Azure Blob Storage completed successfully."
else
    echo "Download from Azure Blob Storage failed!"
    exit 1
fi

# Extract the backup file
tar -xzf "$RESTORE_DIR/backup.tar.gz" -C "$RESTORE_DIR"

# Check if extraction was successful
if [ $? -eq 0 ]; then
    echo "Backup extraction completed successfully."
else
    echo "Backup extraction failed!"
    exit 1
fi

# Remove the tar.gz file after extraction
rm -f "$RESTORE_DIR/backup.tar.gz"

# Find the extracted directory
EXTRACTED_DIR=$(ls -d $RESTORE_DIR/backup_*/)

# Restore MongoDB database
mongorestore --host="$MONGODB_HOST" \
             --username="$MONGODB_USER" --password="$MONGODB_PASS" \
             --authenticationDatabase="$MONGODB_AUTH_DB" \
             --dir "$EXTRACTED_DIR" \
             --drop

# Check if mongorestore was successful
if [ $? -eq 0 ]; then
    echo "Database restoration completed successfully."
else
    echo "Database restoration failed!"
    exit 1
fi

# Clean up
rm -rf "$RESTORE_DIR"

echo "Restore process completed."

root@mongodb-1:~/ankit# cat test.sh 
#!/bin/bash

# MongoDB connection details
MONGO_URI="mongodb://mongo-admin:mongo-pass@mongodb-master:27017/?replicaSet=my-demo-replset"
SAS_TOKEN="se=2099-12-31T23%3A59%3A59Z&sp=racwdl&spr=https&sv=2022-11-02&sr=c&sig=gTUG8z3%2BnWroBfgTsd0SOQeKxQTbn6Yx2rYVxEEaAUg%3D"
AZURE_STORAGE_URL="https://mongodbbackuptesting.blob.core.windows.net/mongodbbkp"

RESTORE_DIR="/var/lib/mongod/backup/incremental"
# Directory where incremental backups are stored
EMPTY_DIR="/var/lib/mongod/backup/empty"


rm -rf "$RESTORE_DIR"
# Create restore directory
mkdir -p "$RESTORE_DIR"

# List all backup files and find the most recent one
LATEST_BACKUP_FILE_NAME=$(azcopy list "$AZURE_STORAGE_URL/incremental?$SAS_TOKEN" | sort | tail -n 1 | cut -d'/' -f1)

# Form the URL to download the latest backup file
BACKUP_FILE="$AZURE_STORAGE_URL/incremental/$LATEST_BACKUP_FILE?$SAS_TOKEN"

# Download the latest backup file from Azure Blob Storage
azcopy copy "$BACKUP_FILE" "$RESTORE_DIR" --recursive

# Check if download was successful
if [ $? -eq 0 ]; then
    echo "Download from Azure Blob Storage completed successfully."
else
    echo "Download from Azure Blob Storage failed!"
    exit 1
fi

# Apply incremental backups in sequence
  mongorestore --uri="$MONGO_URI" --dir=$EMPTY_DIR --oplogReplay --oplogFile=${RESTORE_DIR}/${LATEST_BACKUP_FILE_NAME}/local/oplog.rs.bson --drop
  if [ $? -ne 0 ]; then
    echo "Failed to apply oplog from $backup_dir"
    exit 1
  fi

#Remove Backup direcory from local storage
rm -rf ${RESTORE_DIR}

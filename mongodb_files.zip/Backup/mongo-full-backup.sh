#!/bin/bash

# Configuration
BACKUP_DIR="/var/lib/mongod/backup/full"
DATE=$(date +"%F_%T")
BACKUP_PATH="$BACKUP_DIR/backup_$DATE"
MONGODB_HOST="my-demo-replset/mongodb-master:27017"
MONGODB_USER="mongo-admin"
MONGODB_PASS="mongo-pass"
MONGODB_AUTH_DB="admin"

# Azure Storage Configuration
AZURE_STORAGE_URL="https://mongodbbackuptesting.blob.core.windows.net/mongodbbkp"
SAS_TOKEN="se=2099-12-31T23%3A59%3A59Z&sp=racwdl&spr=https&sv=2022-11-02&sr=c&sig=gTUG8z3%2BnWroBfgTsd0SOQeKxQTbn6Yx2rYVxEEaAUg%3D"
TIMESTAMP=$(date +"%F_%T")

# Create backup directory
mkdir -p "$BACKUP_PATH"

# Perform MongoDB backup
mongodump --host="$MONGODB_HOST" \
          --username="$MONGODB_USER" --password="$MONGODB_PASS" \
          --authenticationDatabase="$MONGODB_AUTH_DB" \
          --out="$BACKUP_PATH"

# Check if mongodump was successful
if [ $? -eq 0 ]; then
    echo "Backup completed successfully."
else
    echo "Backup failed!"
    exit 1
fi

# Compress the backup directory
tar -czf "$BACKUP_PATH.tar.gz" -C "$BACKUP_DIR" "$(basename "$BACKUP_PATH")"

# Check if compression was successful
if [ $? -eq 0 ]; then
    echo "Compression completed successfully."
    # Remove the uncompressed backup directory
    rm -rf "$BACKUP_PATH"
else
    echo "Compression failed!"
    exit 1
fi

# Upload the backup to Azure Blob Storage
azcopy copy "$BACKUP_PATH.tar.gz" "$AZURE_STORAGE_URL/full/$TIMESTAMP.tar.gz?$SAS_TOKEN" --recursive

# Check if upload was successful
if [ $? -eq 0 ]; then
    echo "Upload to Azure Blob Storage completed successfully."
else
    echo "Upload to Azure Blob Storage failed!"
    exit 1
fi

echo "Backup process completed."

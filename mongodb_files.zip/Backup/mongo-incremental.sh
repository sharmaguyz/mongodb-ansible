#!/bin/bash

# Configuration
INCREMENTAL_BACKUP_DIR="/var/lib/mongod/backup/incremental"
LOG_FILE="${INCREMENTAL_BACKUP_DIR}/mongo_incremental_backup.log"
DATE=$(date +"%Y%m%dT%H%M%SZ")
TIMESTAMP_FILE="${INCREMENTAL_BACKUP_DIR}/last_timestamp"
QUERY_DIR="/var/lib/mongod/backup/query"

# MongoDB connection details
MONGO_URI="mongodb://mongo-admin:mongo-pass@mongodb-master:27017/?replicaSet=my-demo-replset"
AUTH_DB="admin"

# Azure Blob Storage configuration
AZURE_STORAGE_URL="https://mongodbbackuptesting.blob.core.windows.net/mongodbbkp"
SAS_TOKEN="se=2099-12-31T23%3A59%3A59Z&sp=racwdl&spr=https&sv=2022-11-02&sr=c&sig=gTUG8z3%2BnWroBfgTsd0SOQeKxQTbn6Yx2rYVxEEaAUg%3D"

# Ensure backup and query directories exist
mkdir -p $INCREMENTAL_BACKUP_DIR
mkdir -p $QUERY_DIR

# Determine the last timestamp for incremental backup
if [ -f $TIMESTAMP_FILE ]; then
  LAST_TIMESTAMP=$(cat $TIMESTAMP_FILE)
else
  LAST_TIMESTAMP=$(date --date="yesterday" +"%s")
fi

# Create query file with last timestamp
echo "{\"ts\":{\"\$gt\":{\"\$timestamp\":{\"t\":$LAST_TIMESTAMP,\"i\":1}}}}" > ${QUERY_DIR}/query.js

# Perform incremental backup using mongodump with queryFile
mongodump --uri="${MONGO_URI}" --authenticationDatabase=$AUTH_DB -d local -c oplog.rs --queryFile=${QUERY_DIR}/query.js -o ${INCREMENTAL_BACKUP_DIR}/${DATE} >> $LOG_FILE 2>&1

# Check if the backup was successful
if [ $? -eq 0 ]; then
  echo "Backup successful: $(date)" | tee -a "$LOG_FILE"

  echo "Uploading backup to Azure Blob Storage..." | tee -a "$LOG_FILE"

  # Upload the backup using azcopy
  azcopy copy "${INCREMENTAL_BACKUP_DIR}/${DATE}" "$AZURE_STORAGE_URL/incremental/${DATE}?$SAS_TOKEN" --recursive >> "$LOG_FILE" 2>&1

  # Check if the Azure upload was successful
  if [ $? -eq 0 ]; then
    echo "Backup successfully uploaded to Azure Blob Storage: $(date)" | tee -a "$LOG_FILE"
  else
    echo "Azure upload failed: $(date)" | tee -a "$LOG_FILE"
    exit 1
  fi

  # Update the last timestamp
  NEW_TIMESTAMP=$(date +"%s")
  echo $NEW_TIMESTAMP > $TIMESTAMP_FILE
else
  # Log failure if mongodump was unsuccessful
  echo "Incremental backup unsuccessful, exiting... $(date)" | tee -a "$LOG_FILE"
  exit 1
fi

# Clean up old backup files (older than 30 days)
find $INCREMENTAL_BACKUP_DIR -name "*.tar.gz" -mtime +30 -exec rm -f {} \;
